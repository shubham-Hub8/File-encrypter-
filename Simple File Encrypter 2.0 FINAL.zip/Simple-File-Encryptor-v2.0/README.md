# Simple File Encryptor — Version 2.0

Simple File Encryptor is a standalone browser application for local file encryption and decryption.

## Version 2.0 features

- Argon2id key derivation, implemented locally from RFC 9106.
- AES-256-GCM authenticated encryption through the Web Crypto API.
- Fresh 16-byte salt and 12-byte IV/nonce for every encrypted file.
- Argon2id memory selection from 12 MiB to 500 MiB; 64 MiB is the default.
- Argon2id uses 3 passes and 4 lanes of parallelism.
- Files up to 1 GB are accepted, subject to browser/device memory limits.
- Single-file encryption and folder/multiple-file encryption into a ZIP archive.
- SFE2 header authenticated as AES-GCM additional authenticated data (AAD).
- Fully local and offline-capable after the application has loaded.

## SFE2 format

`SFE2 | version | KDF | memory | passes | parallelism | salt | IV | AES-GCM ciphertext + tag`

The header records the Argon2id parameters needed for decryption. Authenticating the header prevents silent modification of those parameters.

## Usage

Extract the release ZIP and open `index.html` in a modern browser. No Node.js, npm, local server, CDN, account, or backend is required.

## Security notes

Use a long, unique password. A forgotten password cannot be recovered. High Argon2id memory settings can require substantial RAM. This project has not undergone an independent cryptographic security audit.
