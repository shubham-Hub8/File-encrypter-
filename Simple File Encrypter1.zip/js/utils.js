/* ==========================================
   Simple File Encryptor
   Shared Utilities
========================================== */

"use strict";

/* ---------- DOM Cache ---------- */

const DOM = {

    encryptTab:
        document.getElementById("encryptTab"),

    decryptTab:
        document.getElementById("decryptTab"),

    fileInput:
        document.getElementById("fileInput"),

    chooseFile:
        document.getElementById("chooseFile"),

    dropZone:
        document.getElementById("dropZone"),

    selectedFile:
        document.getElementById("selectedFile"),

    password:
        document.getElementById("password"),

    confirmPassword:
        document.getElementById("confirmPassword"),

    showPassword:
        document.getElementById("showPassword"),

    strength:
        document.getElementById("strength"),

    actionButton:
        document.getElementById("actionButton"),

    progressBar:
        document.getElementById("progressBar"),

    status:
        document.getElementById("status"),

    outputFilename:
        document.getElementById("outputFilename"),

    downloadButton:
        document.getElementById("downloadButton")

};

/* ---------- Application State ---------- */

const State = {

    mode: "encrypt",

    selectedFile: null,

    encryptedBlob: null,

    decryptedBlob: null,

    outputName: "",

    busy: false

};

/* ---------- Status ---------- */

function setStatus(message) {

    DOM.status.textContent = message;

}

function clearStatus() {

    setStatus("Waiting...");

}

/* ---------- Progress ---------- */

function setProgress(percent) {

    const value = Math.max(

        0,

        Math.min(

            100,

            Number(percent)

        )

    );

    DOM.progressBar.style.width =

        value + "%";

}

function resetProgress() {

    setProgress(0);

}

function completeProgress() {

    setProgress(100);

}

/* ---------- Download ---------- */

function enableDownload() {

    DOM.downloadButton.disabled = false;

}

function disableDownload() {

    DOM.downloadButton.disabled = true;

}

/* ---------- Busy State ---------- */

function setBusy(value) {

    State.busy = Boolean(value);

    DOM.actionButton.disabled =

        State.busy;

    DOM.chooseFile.disabled =

        State.busy;

    DOM.fileInput.disabled =

        State.busy;

}
/* ---------- Output ---------- */

function clearOutput() {

    State.encryptedBlob = null;

    State.decryptedBlob = null;

    State.outputName = "";

    DOM.outputFilename.textContent =

        "No file generated.";

    disableDownload();

    resetProgress();

}

/* ---------- File Size ---------- */

function bytesToSize(bytes) {

    if (bytes === 0) {

        return "0 Bytes";

    }

    const units = [

        "Bytes",

        "KB",

        "MB",

        "GB",

        "TB"

    ];

    const index = Math.floor(

        Math.log(bytes) /

        Math.log(1024)

    );

    return (

        bytes /

        Math.pow(1024, index)

    ).toFixed(2)

    + " "

    + units[index];

}

/* ---------- Escape HTML ---------- */

function escapeHTML(text) {

    const div =

        document.createElement("div");

    div.textContent = text;

    return div.innerHTML;

}

/* ---------- Random ID ---------- */

function randomID(length = 8) {

    return crypto

        .getRandomValues(

            new Uint32Array(length)

        )

        .reduce(

            (id, value) =>

                id +

                (value % 36)

                .toString(36),

            ""

        );

}

/* ---------- File Names ---------- */

function removeExtension(filename) {

    const index =

        filename.lastIndexOf(".");

    if (index === -1) {

        return filename;

    }

    return filename.substring(

        0,

        index

    );

}

function getExtension(filename) {

    const index =

        filename.lastIndexOf(".");

    if (index === -1) {

        return "";

    }

    return filename.substring(index);

}

function buildEncryptedName(filename) {

    return filename + ".sfe";

}

function buildDecryptedName(filename) {

    if (

        filename.endsWith(".sfe")

    ) {

        return filename.slice(0, -4);

    }

    return

        removeExtension(filename) +

        "_decrypted";

}
/* ---------- Reset Helpers ---------- */

function resetInterface() {

    clearOutput();

    clearStatus();

    setBusy(false);

}

/* ---------- Browser Support ---------- */

function browserSupported() {

    return (

        window.isSecureContext &&

        window.crypto &&

        window.crypto.subtle &&

        window.File &&

        window.Blob &&

        window.TextEncoder &&

        window.TextDecoder

    );

}

function requireBrowserSupport() {

    if (browserSupported()) {

        return true;

    }

    setStatus(

        "Your browser does not support the required Web Crypto features."

    );

    DOM.actionButton.disabled = true;

    DOM.chooseFile.disabled = true;

    DOM.fileInput.disabled = true;

    return false;

}

/* ---------- Output Helpers ---------- */

function setOutput(blob, filename) {

    if (State.mode === "encrypt") {

        State.encryptedBlob = blob;

        State.decryptedBlob = null;

    }

    else {

        State.decryptedBlob = blob;

        State.encryptedBlob = null;

    }

    State.outputName = filename;

    DOM.outputFilename.textContent = filename;

    enableDownload();

}

/* ---------- Active Blob ---------- */

function getOutputBlob() {

    return (

        State.mode === "encrypt"

            ? State.encryptedBlob

            : State.decryptedBlob

    );

}

/* ---------- Startup ---------- */

resetInterface();

requireBrowserSupport();