/* ==========================================
   Simple File Encryptor
   Application Controller
========================================== */

"use strict";

/* ---------- Action ---------- */

DOM.actionButton.addEventListener(

    "click",

    processAction

);

/* ---------- Process ---------- */

async function processAction() {
if (!hasFile()) {

        alert("Stopped at hasFile");

        return;

    }
if (!validatePassword()) {

        alert("Stopped at validatePassword");

        return;

    }
const file = State.selectedFile;

    const password = getPassword();
await processFile(file, password);
}

/* ---------- Keyboard Shortcut ---------- */

document.addEventListener(

    "keydown",

    event => {

        if (

            event.key === "Enter" &&

            document.activeElement !==

            DOM.actionButton

        ) {

            event.preventDefault();

            processAction();

        }

    }

);

/* ---------- Startup ---------- */

window.addEventListener(

    "load",

    () => {

        setStatus(

            "Waiting..."

        );

        resetProgress();

        disableDownload();

        updateTabs();

        updateActionButton();

        updatePasswordSection();

    }

);