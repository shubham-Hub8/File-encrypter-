/* ==========================================
   Simple File Encryptor
   User Interface
========================================== */

"use strict";

/* ---------- Encrypt Mode ---------- */

DOM.encryptTab.addEventListener(

    "click",

    () => {

        setMode("encrypt");

    }

);

/* ---------- Decrypt Mode ---------- */

DOM.decryptTab.addEventListener(

    "click",

    () => {

        setMode("decrypt");

    }

);

/* ---------- Mode ---------- */

function setMode(mode) {

    if (

        State.mode === mode

    ) {

        return;

    }

    State.mode = mode;

    updateTabs();

    updateActionButton();

    updatePasswordSection();

    clearOutput();

    resetProgress();

    setStatus(

        mode === "encrypt"

            ? "Encryption mode selected."

            : "Decryption mode selected."

    );

}

/* ---------- Tabs ---------- */

function updateTabs() {

    DOM.encryptTab.classList.toggle(

        "active",

        State.mode === "encrypt"

    );

    DOM.decryptTab.classList.toggle(

        "active",

        State.mode === "decrypt"

    );

}

/* ---------- Action Button ---------- */

function updateActionButton() {

    DOM.actionButton.textContent =

        State.mode === "encrypt"

            ? "Encrypt File"

            : "Decrypt File";

}

/* ---------- Confirm Password ---------- */

function updatePasswordSection() {

    const label =

        DOM.confirmPassword

            .previousElementSibling;

    const visible =

        State.mode === "encrypt";

    label.hidden = !visible;

    DOM.confirmPassword.hidden = !visible;

    if (!visible) {

        DOM.confirmPassword.value = "";

        DOM.confirmPassword.style.borderColor = "";

    }

}

/* ---------- Reset ---------- */

function resetUI() {

    DOM.password.value = "";

    DOM.confirmPassword.value = "";

    DOM.showPassword.checked = false;

    DOM.password.type = "password";

    DOM.confirmPassword.type = "password";

    DOM.strength.textContent =

        "Strength: —";

    DOM.strength.style.color =

        "";

    DOM.selectedFile.textContent =

        "No file selected";

    clearOutput();

    resetProgress();

    updateTabs();

    updateActionButton();

    updatePasswordSection();

    setStatus("Waiting...");

}

/* ---------- Startup ---------- */

resetUI();