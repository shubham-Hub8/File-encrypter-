/* ==========================================
   Simple File Encryptor
   File Management
========================================== */

"use strict";

/* ---------- Configuration ---------- */

const MAX_FILE_SIZE = 1024 * 1024 * 1024; // 1 GB

/* ---------- Choose File Button ---------- */

DOM.chooseFile.addEventListener("click", () => {

    DOM.fileInput.click();

});

/* ---------- File Picker ---------- */

DOM.fileInput.addEventListener("change", (event) => {

    const file = event.target.files[0];

    if (!file) {

        return;

    }

    loadFile(file);

});

/* ---------- Load File ---------- */

function loadFile(file) {

    if (!(file instanceof File)) {

        setStatus("Invalid file.");

        return false;

    }

    if (file.size === 0) {

        setStatus("The selected file is empty.");

        return false;

    }

    if (file.size > MAX_FILE_SIZE) {

        setStatus("File exceeds the 1 GB size limit.");

        DOM.fileInput.value = "";

        return false;

    }

    State.selectedFile = file;

    clearOutput();

    DOM.selectedFile.innerHTML = `
        <strong>${escapeHTML(file.name)}</strong><br>
        ${bytesToSize(file.size)}
    `;

    setStatus("File loaded successfully.");

    return true;

}

/* ---------- Clear File ---------- */

function clearFile() {

    State.selectedFile = null;

    DOM.fileInput.value = "";

    DOM.selectedFile.textContent = "No file selected";

    clearOutput();

}

/* ---------- Validation ---------- */

function hasFile() {

    if (!State.selectedFile) {

        setStatus("Please choose a file first.");

        return false;

    }

    return true;

}